# AutoDJ for Listen2MyRadio

This AutoDJ package plays your playlist on loop and streams to your Icecast server.

## Deployment (Render.com)
1. Upload all files in this folder to a new GitHub repository.
2. On Render, click "New + → Web Service".
3. Select your repo.
4. Set Environment = Docker.
5. Click Deploy.

Your AutoDJ will stream 24/7.